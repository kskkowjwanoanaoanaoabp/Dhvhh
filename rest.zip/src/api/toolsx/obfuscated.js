const axios = require('axios');
const JsConfuser = require('js-confuser'); // Pastikan Anda menginstal js-confuser

module.exports = function(app) {
    
    // Fungsi untuk melakukan obfuscation pada kode dengan waktu kadaluarsa
    const obfuscateTimeLocked = async (days, code) => {
        try {
            // Menghitung timestamp kadaluarsa berdasarkan jumlah hari yang diberikan
            const expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + parseInt(days));
            const expiryTimestamp = expiryDate.getTime();
            
            const expiryCheck = `(function(){const expiry=${expiryTimestamp};if(new Date().getTime()>expiry){throw new Error('Script has expired after ${days} days');}${code}})();`;

            // Melakukan obfuscation dengan JsConfuser
            const obfuscated = await JsConfuser.obfuscate(expiryCheck, {
                target: 'node',
                calculator: true,
                compact: true,
                hexadecimalNumbers: true,
                controlFlowFlattening: 0.5,
                deadCode: 0.1,
                flatten: true,
                shuffle: true,
                stringCompression: true,
                stringConcealing: false,
                stringEncoding: true,
                identifierGenerator: "randomized", 
                lock: {
                selfDefending: true,
                antiDebug: (code) => `if(typeof debugger!=='undefined'||(typeof process!=='undefined'      process.env.NODE_ENV==='debug'))throw new Error('Debugging disabled');{code}`,
                integrity: true,
                tamperProtection: (code) => `if(!((function(){return eval('1+1')===2;})()))throw new Error('Tamper detected');code`
                }
            });
            return {
                status: true,
                obfuscatedCode: obfuscated.code // Mengembalikan kode yang sudah diobfuscate
            };

        } catch (error) {
            console.error("Error during obfuscation:", error.message);
            throw error;
        }
    };

    // Endpoint untuk melakukan obfuscation dengan parameter `days` dan `code`
    app.get('/toolsx/obfuscate', async (req, res) => {
        try {
            const { days, code } = req.query; // Mengambil parameter `days` dan `code` dari query string
            
            // Validasi parameter
            if (!days) {
                return res.status(400).json({ error: 'Parameter `days` is required' });
            }
            if (!code) {
                return res.status(400).json({ error: 'Parameter `code` is required' });
            }

            // Melakukan obfuscation pada kode yang diberikan
            const data = await obfuscateTimeLocked(days, code);
            
            // Mengembalikan data obfuscated dalam bentuk JSON
            res.json(data);

        } catch (error) {
            res.status(500).json({ error: 'Internal Server Error' });
        }
    });
};