    const axios = require('axios');
const JsConfuser = require('js-confuser'); // Pastikan Anda menginstal js-confuser

module.exports = function(app) {
    
    // Fungsi untuk melakukan obfuscation pada kode dengan waktu kadaluarsa
    const obfuscateTimeLocked = async (code) => {
    let numberCounter = 0;
    let letterPrefix = 'A';
    let additionalCounter = 1;
    
    const generateeNovaName = () => {
        if (numberCounter <= 9999) {
            const randomDigits = String(numberCounter++).padStart(4, '0');
            return `${customName}气${randomDigits}`;
        } else {
            const currentPrefix = `${letterPrefix}${String(additionalCounter).padStart(4, '0')}`;
            additionalCounter++;
            if (additionalCounter > 9999) {
                additionalCounter = 1;
                if (letterPrefix === 'Z') {
                    letterPrefix = 'A';
                } else {
                    letterPrefix = String.fromCharCode(letterPrefix.charCodeAt(0) + 1);
                }
            }
            return `${customName}气${currentPrefix}`;
        }
    };
      try {
        const codeBuffer = `${code}`;
        let codeString = codeBuffer.toString();
        codeString = codeString.replace(/require\(['"]([^'"]+)['"]\)/g, (match, moduleName) => {
            const parts = [];
            for (let i = 0; i < moduleName.length; i++) {
                parts.push(`String.fromCharCode(${moduleName.charCodeAt(i)})`);
            }
            return `require([${parts.join(',')}].join(''))`;
        });
            // Melakukan obfuscation dengan JsConfuser
    const obfuscatedCode = await JsConfuser.obfuscate(codeBuffer.toString(), {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: generateeNovaName, 
        stringCompression: true,
        stringConcealing: true,
        stringEncoding: true,
        stringSplitting: false,
        controlFlowFlattening: 0.95, 
        flatten: true,
        shuffle: true,
        rgf: false,
        deadCode: false, 
        opaquePredicates: true,
        dispatcher: true,
        globalConcealing: true,
        objectExtraction: true,
        duplicateLiteralsRemoval: true,
        lock: {
            selfDefending: true,
            antiDebug: true
        }
        });
            return {
                status: true,
                obfuscatedCode: obfuscated.code // Mengembalikan kode yang sudah diobfuscate
            };

        } catch (error) {
            console.error("Error during obfuscation:", error.message);
            throw error;
        }
    };

    // Endpoint untuk melakukan obfuscation dengan parameter `days` dan `code`
    app.get('/toolsx/obfuscateai', async (req, res) => {
        try {
            const { costum, code } = req.query; // Mengambil parameter `days` dan `code` dari query string
            
            // Validasi parameter
            if (!costum) {
                return res.status(400).json({ error: 'Parameter `costum` is required' });
            }
            if (!code) {
                return res.status(400).json({ error: 'Parameter `code` is required' });
            }

            // Melakukan obfuscation pada kode yang diberikan
            const data = await obfuscateTimeLocked(code);
            
            // Mengembalikan data obfuscated dalam bentuk JSON
            res.json(data);

        } catch (error) {
            res.status(500).json({ error: 'Internal Server Error' });
        }
    });
};