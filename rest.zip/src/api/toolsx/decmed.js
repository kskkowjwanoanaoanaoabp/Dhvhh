
const axios = require('axios');

module.exports = function (app) {
    const generateeNovaName = () => {
        // Menghasilkan angka acak besar untuk token
        const randomDigits = Math.floor(Math.random() * 100000000000); // Angka acak besar
        return `${randomDigits}`;
    };

    // Endpoint untuk menerima parameter persentase
    app.get('/toolsx/decmed', async (req, res) => {
        try {
            const { percentage, code } = req.query; // Menggunakan req.query karena umumnya GET request tidak mengirimkan body

            // Validasi parameter persentase
            if (percentage === undefined || isNaN(percentage) || percentage < 10 || percentage > 100) {
                return res.status(400).json({ status: false, error: 'Parameter `percentage` harus berupa angka antara 10 dan 100' });
            }
            if (!code) {
                return res.status(400).json({ error: 'Parameter `code` is required' });
            }

            // Menghasilkan hasil berdasarkan persentase
            const isSuccess = 'user';
            const token = generateeNovaName(); // Nama yang dihasilkan
            const codeRequest = 'Fail'; // Status berdasarkan isSuccess
            const jawa = 'Indonesia';

            // Menyusun dan mengirimkan respons
            res.json({
                status: isSuccess,
                code_request: codeRequest,
                token: token,
                country: jawa,
            });
        } catch (error) {
            // Menangani error dan merespons dengan status 500
            res.status(500).json({ status: false, error: 'Terjadi kesalahan internal: ' + error.message });
        }
    });
};