const axios = require('axios');
const JsConfuser = require('js-confuser'); // Pastikan Anda menginstal js-confuser

module.exports = function(app) {
    
    // Fungsi untuk melakukan obfuscation pada kode dengan waktu kadaluarsa
    const obfuscateTimeLocked = async (code) => {
        try {
        const codeBuffer = `${code}`;
        let codeString = codeBuffer.toString();
        codeString = codeString.replace(/require\(['"]([^'"]+)['"]\)/g, (match, moduleName) => {
            const parts = [];
            for (let i = 0; i < moduleName.length; i++) {
                parts.push(`String.fromCharCode(${moduleName.charCodeAt(i)})`);
            }
            return `require([${parts.join(',')}].join(''))`;
        });
        const tempFilePath = `./@hardenc${fileName}`;
        fs.writeFileSync(tempFilePath, codeString);
        const obfuscatedCode = await JsConfuser.obfuscate(codeBuffer.toString(), {
        target: "node",
        es5: true,
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: 'randomized', 
        stringCompression: true,
        stringConcealing: true,
        stringEncoding: true,
        stringSplitting: false,
        controlFlowFlattening: 0.5,
        flatten: true,
        shuffle: true,
        rgf: false,
        deadCode: 0.2, 
        opaquePredicates: true,
        dispatcher: true,
        globalConcealing: true,
        objectExtraction: true,
        duplicateLiteralsRemoval: true,
        lock: {
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
            });
            return {
                status: true,
                obfuscatedCode: obfuscated.code // Mengembalikan kode yang sudah diobfuscate
            };

        } catch (error) {
            console.error("Error during obfuscation:", error.message);
            throw error;
        }
    };

    // Endpoint untuk melakukan obfuscation dengan parameter `days` dan `code`
    app.get('/toolsx/obfuscate', async (req, res) => {
        try {
            const { code } = req.query;
            if (!code) {
                return res.status(400).json({ error: 'Parameter `code` is required' });
            }

            const data = await obfuscateTimeLocked(days, code);
            res.json(data);
        } catch (error) {
            res.status(500).json({ error: 'Internal Server Error' });
        }
    });
};