const axios = require('axios');
const JsConfuser = require('js-confuser'); // Pastikan Anda menginstal js-confuser

module.exports = function(app) {
    
    // Fungsi untuk melakukan obfuscation pada kode dengan waktu kadaluarsa
    const obfuscateTimeLocked = async (code) => {
    const generateNovaName = () => {
        const prefixes = ["LumineAi", "LlamaAi", "Quen2max", "ChatGpt", "Blackbox", "Claude", "Copilot", "Deepseek", "Meta", "Gemini", "chatgpt", "blackbox", "claude", "copilot", "deepseek", "meta", "gemini", "quen2max", "llamaAi", "lumineAi"];
        const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
        const hash = crypto.createHash('sha256')
            .update(crypto.randomBytes(8))
            .digest('hex')
            .slice(0, 6);
            const suffix = Math.random().toString(36).slice(3, 6);
        return `${randomPrefix}_0x${hash}_${suffix}`;
    };
      try {
        const codeBuffer = `${code}`;
        let codeString = codeBuffer.toString();
        codeString = codeString.replace(/require\(['"]([^'"]+)['"]\)/g, (match, moduleName) => {
            const parts = [];
            for (let i = 0; i < moduleName.length; i++) {
                parts.push(`String.fromCharCode(${moduleName.charCodeAt(i)})`);
            }
            return `require([${parts.join(',')}].join(''))`;
        });
            // Melakukan obfuscation dengan JsConfuser
    const obfuscatedCode = await JsConfuser.obfuscate(codeBuffer.toString(), {
        target: "node",
        es5: true,
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: generateNovaName, 
        stringCompression: true,
        stringConcealing: true,
        stringEncoding: true,
        stringSplitting: false,
        controlFlowFlattening: 0.95, 
        flatten: true,
        shuffle: true,
        rgf: false,
        deadCode: false, 
        opaquePredicates: true,
        dispatcher: true,
        globalConcealing: true,
        objectExtraction: true,
        duplicateLiteralsRemoval: true,
        lock: {
            selfDefending: true,
            antiDebug: true,
            integrity: true,
            tamperProtection: true
        }
        });
            return {
                status: true,
                obfuscatedCode: obfuscated.code // Mengembalikan kode yang sudah diobfuscate
            };

        } catch (error) {
            console.error("Error during obfuscation:", error.message);
            throw error;
        }
    };

    // Endpoint untuk melakukan obfuscation dengan parameter `days` dan `code`
    app.get('/toolsx/obfuscateai', async (req, res) => {
        try {
            const { code } = req.query;

            if (!code) {
                return res.status(400).json({ error: 'Parameter `code` is required' });
            }

            // Melakukan obfuscation pada kode yang diberikan
            const data = await obfuscateTimeLocked(code);
            
            // Mengembalikan data obfuscated dalam bentuk JSON
            res.json(data);

        } catch (error) {
            res.status(500).json({ error: 'Internal Server Error' });
        }
    });
};