const express = require('express');
const chalk = require('chalk');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 4000;
const ATMIN_PASSWORD = "thisydqrsc";  // Ganti dengan password yang lebih aman
let maintenanceMode = false;

app.enable("trust proxy");
app.set("json spaces", 2);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());

app.use(session({ secret: 'secret-key', resave: false, saveUninitialized: true }));

const settingsPath = path.join(__dirname, './src/settings.json');
const settings = JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));

app.use((req, res, next) => {
    if (maintenanceMode && req.path !== '/maintenance.html') {
        return res.redirect('/maintenance.html');
    }
    next();
});

app.use('/', express.static(path.join(__dirname, 'api-page')));
app.use('/src', express.static(path.join(__dirname, 'src')));

// API Routes Loader
let totalRoutes = 0;
const apiFolder = path.join(__dirname, './src/api');
fs.readdirSync(apiFolder).forEach((subfolder) => {
    const subfolderPath = path.join(apiFolder, subfolder);
    if (fs.statSync(subfolderPath).isDirectory()) {
        fs.readdirSync(subfolderPath).forEach((file) => {
            const filePath = path.join(subfolderPath, file);
            if (path.extname(file) === '.js') {
                require(filePath)(app);
                totalRoutes++;
                console.log(chalk.bgHex('#FFFF99').hex('#333').bold(` Loaded Route: ${path.basename(file)} `));
            }
        });
    }
});

console.log(chalk.bgHex('#90EE90').hex('#333').bold(' Load Complete! ✓ '));
console.log(chalk.bgHex('#90EE90').hex('#333').bold(` Total Routes detected : ${totalRoutes} `));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'api-page', 'home.html'));
});

// Folder upload
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadDir),
    filename: (req, file, cb) => cb(null, file.originalname)
});
const upload = multer({ storage });

// Login atmin
app.post('/atmin/atmin2', (req, res) => {
    if (req.body.password === ATMIN_PASSWORD) {
        req.session.atmin = true;
        res.json({ success: true });
    } else {
        res.json({ success: false });
    }
});

// Logout atmin
app.post('/atmin/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

// Middleware untuk proteksi atmin
const authMiddleware = (req, res, next) => {
    if (!req.session.atmin) return res.status(403).json({ error: "Unauthorized" });
    next();
};

// File Manager Routes
app.get('/atmin/files', authMiddleware, (req, res) => {
    fs.readdir(uploadDir, (err, files) => {
        if (err) return res.status(500).json({ error: "Gagal membaca folder" });
        res.json(files);
    });
});

app.post('/atmin/upload', authMiddleware, upload.single('file'), (req, res) => {
    res.json({ message: "File uploaded successfully", file: req.file.filename });
});

app.delete('/atmin/delete/:filename', authMiddleware, (req, res) => {
    const filePath = path.join(uploadDir, req.params.filename);
    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        res.json({ message: "File deleted" });
    } else {
        res.status(404).json({ error: "File not found" });
    }
});

// File Editor Routes
app.get('/atmin/edit/:filename', authMiddleware, (req, res) => {
    const filePath = path.join(uploadDir, req.params.filename);
    if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, 'utf-8');
        res.json({ content });
    } else {
        res.status(404).json({ error: "File not found" });
    }
});

app.post('/atmin/edit/:filename', authMiddleware, (req, res) => {
    const filePath = path.join(uploadDir, req.params.filename);
    fs.writeFileSync(filePath, req.body.content, 'utf-8');
    res.json({ message: "File updated successfully" });
});

// Maintenance Mode
app.post('/atmin/maintenance/on', authMiddleware, (req, res) => {
    maintenanceMode = true;
    res.json({ message: "Maintenance mode activated" });
});

app.post('/atmin/maintenance/off', authMiddleware, (req, res) => {
    maintenanceMode = false;
    res.json({ message: "Maintenance mode deactivated" });
});

// Error Handling
app.use((req, res, next) => {
    res.status(404).sendFile(process.cwd() + "/api-page/404.html");
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).sendFile(process.cwd() + "/api-page/500.html");
});


// Rute untuk dashboard atmin
app.get('/atmin', (req, res) => {
    res.sendFile(path.join(__dirname, 'api-page', 'atmin.html'));
});


module.exports = app;


// Menjalankan server
app.listen(PORT, () => {
    console.log(chalk.bgHex('#ADD8E6').hex('#333').bold(` Server running on http://localhost:${PORT} `));
});
